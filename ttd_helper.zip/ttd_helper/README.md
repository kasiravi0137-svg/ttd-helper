# TTD Helper

Flutter app that saves your booking details once and fills the TTD special entry darshan form for you inside a WebView.

You always do these yourself on the TTD page: OTP, captcha, payment.

## Build the APK on GitHub

1. Create a new GitHub repo and push this whole folder to the `main` branch.
2. Open the repo, then Actions, then "Build APK". It runs on every push, or press "Run workflow".
3. When it finishes (about 5 minutes), open the run and download `ttd-helper-apk` from Artifacts.
4. Unzip it, copy `app-release.apk` to your phone and install it (allow "install unknown apps").

The workflow creates the `android/` folder by itself on the first run, so you don't need Flutter installed.

## What the app does

- Home: shows the saved booking, Start booking, Edit details, Delete all.
- Details: edit or delete devotees, Clear form, Save. Everything is stored encrypted on the phone.
- Booking: opens the TTD site, clicks Login, fills your phone number, waits for your OTP,
  then clicks Online services and Special Entry Darshan, and fills date, slot, devotees and general details.
- "Autofill page" fills whatever form is open right now, any time.
- If a step can't be found automatically, the app tells you what to do and waits for "Done, next".

## If the TTD site changes

The page logic is in `assets/ttd_automation.js`. Buttons and fields are found by their visible text and labels
(for example `Login`, `Online services`, `Photo ID Proof`). If TTD renames something, edit the words in that file.
The site address is `kTtdUrl` in `lib/screens/browser_screen.dart`.
