(function () {
  if (window.__ttd && window.__ttd.v === 4) return;
  const state = (window.__ttd && window.__ttd.state) || { sawDialog: false, gone: 0, iconClicks: 0 };

  // ---------- small helpers ----------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) =>
    (s || '')
      .toString()
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  const vis = (e) => {
    if (!e || !e.getBoundingClientRect) return false;
    const r = e.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const s = getComputedStyle(e);
    return s.visibility !== 'hidden' && s.display !== 'none';
  };
  const has = (text, keys) => {
    const x = ' ' + norm(text) + ' ';
    return keys.some((k) => x.includes(' ' + norm(k) + ' '));
  };
  const post = (o) => {
    try {
      TTD.postMessage(JSON.stringify(o));
    } catch (e) {}
  };
  const done = (ok, msg, extra) =>
    post(Object.assign({ type: 'result', ok: !!ok, msg: msg || '' }, extra || {}));
  const run = async (fn) => {
    try {
      await fn();
    } catch (e) {
      done(false, String(e));
    }
  };
  const PE = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;

  function fireClick(el) {
    try {
      el.scrollIntoView({ block: 'center' });
    } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: r.left + r.width / 2,
      clientY: r.top + r.height / 2,
    };
    el.dispatchEvent(new PE('pointerdown', o));
    el.dispatchEvent(new MouseEvent('mousedown', o));
    el.dispatchEvent(new PE('pointerup', o));
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.dispatchEvent(new MouseEvent('click', o));
  }

  const PHONE = ['mobile', 'mobile number', 'registered mobile number', 'phone', 'phone number'];

  function labelOf(el) {
    let t = [
      el.placeholder,
      el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname'),
      el.getAttribute('name'),
    ]
      .filter(Boolean)
      .join(' ');
    let lab = null;
    if (el.id) {
      try {
        lab = document.querySelector('label[for="' + el.id + '"]');
      } catch (e) {}
    }
    if (!lab) {
      const ff = el.closest('mat-form-field,.mat-form-field,.mat-mdc-form-field');
      if (ff) lab = ff.querySelector('label,mat-label');
    }
    if (!lab && el.parentElement) lab = el.parentElement.querySelector('label');
    if (lab) t += ' ' + lab.innerText;
    return t;
  }

  function setVal(el, v) {
    const proto =
      el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const d = Object.getOwnPropertyDescriptor(proto, 'value');
    el.scrollIntoView({ block: 'center' });
    el.focus();
    d.set.call(el, v);
    ['input', 'change', 'blur'].forEach((n) => el.dispatchEvent(new Event(n, { bubbles: true })));
  }

  const SKIP = ['hidden', 'checkbox', 'radio', 'button', 'submit', 'file'];
  const inputs = (keys) =>
    [...document.querySelectorAll('input,textarea')].filter(
      (e) => vis(e) && !SKIP.includes(e.type) && has(labelOf(e), keys)
    );
  const selects = (keys) =>
    [...document.querySelectorAll('select,mat-select,[role=combobox]')].filter(
      (e) => e.tagName !== 'INPUT' && vis(e) && has(labelOf(e), keys)
    );

  function clickText(texts, exact) {
    const want = texts.map(norm);
    let best = null;
    let bl = 1e9;
    document
      .querySelectorAll(
        'button,a,li,span,div,label,mat-option,[role=button],[role=option],[role=menuitem],[role=tab]'
      )
      .forEach((e) => {
        if (!vis(e)) return;
        const t = norm(e.innerText);
        if (!t || t.length > 60) return;
        const ok = want.some((w) =>
          exact ? t === w : t === w || (' ' + t + ' ').includes(' ' + w + ' ')
        );
        if (ok && t.length <= bl) {
          best = e;
          bl = t.length;
        }
      });
    if (best) {
      best.scrollIntoView({ block: 'center' });
      best.click();
      return true;
    }
    return false;
  }

  function present(texts) {
    const want = texts.map(norm);
    return [
      ...document.querySelectorAll('a,button,span,li,div,p,h1,h2,h3,h4,[role=button],[role=menuitem]'),
    ].some((e) => {
      if (!vis(e)) return false;
      const t = norm(e.innerText);
      return t && t.length < 40 && want.some((w) => t === w);
    });
  }

  // ---------- dropdowns (works with native, mat-select and custom ones) ----------
  function labelEls(keys) {
    const want = keys.map(norm);
    const c = [];
    document
      .querySelectorAll('label,mat-label,span,div,p,legend,h1,h2,h3,h4,h5,h6')
      .forEach((e) => {
        if (!vis(e)) return;
        const t = norm(e.innerText);
        if (t && t.length < 40 && want.includes(t)) c.push(e);
      });
    return c.filter((e) => !c.some((o) => o !== e && e.contains(o)));
  }

  function controlFor(lab) {
    let c = lab;
    for (let i = 0; i < 5 && c.parentElement; i++) {
      c = c.parentElement;
      const r = c.getBoundingClientRect();
      if (r.height >= 40 && r.height <= 170) return c;
    }
    return lab.parentElement || lab;
  }

  const OPT_STRICT = 'mat-option,[role=option],li,.mat-option,.mat-mdc-option,.option';
  const OPT_LOOSE = OPT_STRICT + ',.dropdown-item,button,a,div,span,p';

  function findOption(value, ctl, strict) {
    const w = norm(value);
    const pool = [...document.querySelectorAll(strict ? OPT_STRICT : OPT_LOOSE)].filter(
      (e) => vis(e) && !ctl.contains(e) && !e.contains(ctl)
    );
    const t = (e) => norm(e.innerText);
    let c = pool.filter((e) => t(e) === w);
    if (!c.length && !strict) {
      c = pool.filter((e) => {
        const x = t(e);
        return x && x.length <= w.length + 6 && x.startsWith(w.slice(0, 4));
      });
    }
    return c.length ? c[c.length - 1] : null;
  }

  function optionTexts(ctl) {
    return [...document.querySelectorAll('mat-option,[role=option],li')]
      .filter((e) => vis(e) && !ctl.contains(e))
      .map((e) => (e.innerText || '').trim())
      .filter((s) => s && s.length < 30);
  }

  async function openAndPick(ctl, value, strict) {
    ctl.scrollIntoView({ block: 'center' });
    await sleep(250);
    const r = ctl.getBoundingClientRect();
    const hit =
      (document.elementFromPoint && document.elementFromPoint(r.left + r.width * 0.5, r.top + r.height * 0.7)) ||
      ctl;
    fireClick(hit);
    await sleep(700);
    let opt = findOption(value, ctl, strict);
    if (!opt) {
      const trig = ctl.querySelector(
        'mat-select,[role=combobox],[role=button],.mat-select-trigger,.mat-mdc-select-trigger,mat-icon,svg,button'
      );
      if (trig) {
        fireClick(trig);
        await sleep(700);
        opt = findOption(value, ctl, strict);
      }
    }
    if (!opt) {
      const seen = optionTexts(ctl).slice(0, 6).join(' | ');
      return { ok: false, why: 'option "' + value + '" not found' + (seen ? ' (page shows: ' + seen + ')' : '') };
    }
    fireClick(opt);
    await sleep(500);
    return { ok: true };
  }

  async function pickFrom(el, value) {
    const w = norm(value);
    if (el.tagName === 'SELECT') {
      const o =
        [...el.options].find((x) => norm(x.text) === w) ||
        [...el.options].find((x) => norm(x.text).includes(w));
      if (!o) return false;
      el.value = o.value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    el.scrollIntoView({ block: 'center' });
    fireClick(el);
    await sleep(600);
    const o = findOption(value, el, true);
    if (!o) return false;
    fireClick(o);
    await sleep(400);
    return true;
  }

  async function fillDropdown(keys, value, idx) {
    if (!value) return { ok: false, why: 'no value' };
    const s = selects(keys)[idx];
    if (s && (await pickFrom(s, value))) return { ok: true };
    const labs = labelEls(keys);
    if (!labs[idx]) return { ok: false, why: 'field not found' };
    const lab = labs[idx];
    const ctl = controlFor(lab);
    const res = await openAndPick(ctl, value, false);
    if (!res.ok) return res;
    const after = norm(ctl.innerText);
    if (after === norm(lab.innerText) || after.length <= norm(lab.innerText).length) {
      return { ok: false, why: 'tapped but nothing was selected' };
    }
    return { ok: true };
  }

  async function fillAny(keys, value, idx) {
    if (!value) return false;
    const i = inputs(keys)[idx];
    if (!i || i.disabled) return false;
    setVal(i, value);
    await sleep(450);
    const w = norm(value);
    const opts = [...document.querySelectorAll('mat-option,[role=option]')].filter(vis);
    const o =
      opts.find((e) => norm(e.innerText) === w) ||
      opts.find((e) => norm(e.innerText).includes(w));
    if (o) {
      fireClick(o);
      await sleep(300);
    }
    return true;
  }

  // ---------- forms ----------
  async function fillDevotees(list) {
    let n = 0;
    const fails = [];
    for (let i = 0; i < list.length; i++) {
      const x = list[i];
      let names = inputs(['name']);
      if (!names[i] && i > 0) {
        clickText(['add devotee', 'add pilgrim', 'add member', 'add more devotee'], false);
        await sleep(900);
        names = inputs(['name']);
      }
      if (!names[i]) {
        if (i === 0) return { n: -1, fails };
        fails.push('devotee ' + (i + 1) + ' form');
        continue;
      }
      const tag = list.length > 1 ? ' ' + (i + 1) : '';
      if (await fillAny(['name'], x.name, i)) n++;
      else fails.push('name' + tag);
      if (!(await fillAny(['age'], x.age, i))) fails.push('age' + tag);
      const g = await fillDropdown(['gender', 'sex'], x.gender, i);
      if (!g.ok) fails.push('gender' + tag + ' (' + g.why + ')');
      const p = await fillDropdown(['photo id proof', 'id proof', 'id type'], x.idType, i);
      if (!p.ok) fails.push('ID proof' + tag + ' (' + p.why + ')');
      await sleep(600);
      if (!(await fillAny(['photo id number', 'id number', 'id no'], x.idNumber, i)))
        fails.push('ID number' + tag);
    }
    return { n, fails };
  }

  async function fillGeneral(g) {
    let n = 0;
    const fails = [];
    const items = [
      ['email', ['email', 'email id', 'mail id'], g.email],
      ['city', ['city'], g.city],
      ['state', ['state'], g.state],
      ['country', ['country'], g.country],
      ['pincode', ['pincode', 'pin code', 'zip', 'postal code'], g.pincode],
    ];
    for (const it of items) {
      if (await fillAny(it[1], it[2], 0)) n++;
      else fails.push(it[0]);
      await sleep(250);
    }
    return { n, fails };
  }

  // ---------- login icon ----------
  const LOGIN_RE = /log[-_ ]?in|sign[-_ ]?in|exit_to_app/i;
  const LOGOUT_RE = /log[-_ ]?out|sign[-_ ]?out|power/i;

  function headerIcon() {
    const W = window.innerWidth;
    const c = [
      ...document.querySelectorAll('button,a,[role=button],mat-icon,i,svg,img,span,div'),
    ].filter((e) => {
      if (!vis(e)) return false;
      const r = e.getBoundingClientRect();
      return (
        r.width >= 18 &&
        r.width <= 90 &&
        r.height >= 18 &&
        r.height <= 90 &&
        r.left > W * 0.7 &&
        r.top + (window.scrollY || 0) < 650 &&
        (e.innerText || '').trim().length <= 20
      );
    });
    if (!c.length) return null;
    c.sort((a, b) => {
      const ra = a.getBoundingClientRect();
      const rb = b.getBoundingClientRect();
      return rb.right - ra.right || rb.width * rb.height - ra.width * ra.height;
    });
    const top = c[0];
    return top.closest('button,a,[role=button]') || top;
  }
  function iconKind(el) {
    const h = (el.outerHTML || '').slice(0, 600);
    if (LOGOUT_RE.test(h)) return 'logout';
    if (LOGIN_RE.test(h)) return 'login';
    return 'unknown';
  }
  function otpVisible() {
    return [...document.querySelectorAll('input,button,label,span,div,p,h1,h2,h3')].some((e) => {
      if (!vis(e)) return false;
      const t = e.tagName === 'INPUT' ? labelOf(e) : e.innerText;
      const n = norm(t);
      return n && n.length < 80 && (' ' + n + ' ').includes(' otp ');
    });
  }

  // ---------- calendar ----------
  const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
  const MONTH_RE = new RegExp('^(' + MONTHS.join('|') + ')\\s+\\d{4}$', 'i');

  function calHeader() {
    return [...document.querySelectorAll('div,span,h1,h2,h3,h4,h5,p,th,button')].find(
      (e) => vis(e) && MONTH_RE.test((e.innerText || '').trim())
    );
  }

  async function gotoMonth(year, month0) {
    for (let k = 0; k < 14; k++) {
      const h = calHeader();
      if (!h) return true;
      const parts = h.innerText.trim().toLowerCase().split(/\s+/);
      const diff = (year - parseInt(parts[1], 10)) * 12 + (month0 - MONTHS.indexOf(parts[0]));
      if (diff === 0) return true;
      const hr = h.getBoundingClientRect();
      const W = window.innerWidth;
      const arrows = [
        ...document.querySelectorAll('button,[role=button],a,mat-icon,i,svg,img,span,div'),
      ].filter((e) => {
        if (!vis(e)) return false;
        const r = e.getBoundingClientRect();
        const sideOk = diff > 0 ? r.left > W * 0.7 : r.right < W * 0.3;
        return (
          r.width >= 18 && r.width <= 80 && r.height >= 18 && r.height <= 80 &&
          r.top > hr.top && r.top < hr.bottom + 520 && sideOk &&
          (e.innerText || '').trim().length <= 16
        );
      });
      if (!arrows.length) return false;
      arrows.sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return rb.width * rb.height - ra.width * ra.height;
      });
      fireClick(arrows[0].closest('button,[role=button],a') || arrows[0]);
      await sleep(650);
    }
    return false;
  }

  function bgOf(el) {
    let e = el;
    for (let i = 0; i < 5 && e; i++) {
      const c = getComputedStyle(e).backgroundColor || '';
      const m = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
      if (m && (m[4] === undefined || parseFloat(m[4]) > 0.2)) return [+m[1], +m[2], +m[3]];
      e = e.parentElement;
    }
    return null;
  }
  function dateState(rgb) {
    if (!rgb) return 'ok';
    const r = rgb[0], g = rgb[1], b = rgb[2];
    if (r > 110 && g < 80 && b < 80) return 'full';
    if (Math.abs(r - g) < 14 && Math.abs(g - b) < 14 && r > 170 && r < 236) return 'na';
    if (b > r + 30 && g > 140 && b > g) return 'notreleased'; // light blue, not the purple "selected" cell
    return 'ok';
  }

  // ---------- public API ----------
  window.__ttd = {
    v: 4,
    state,

    openLogin() {
      return run(async () => {
        if (inputs(PHONE).length) return done(true, 'Login box already open');
        if (clickText(['login', 'log in', 'sign in'], true)) return done(true, 'Clicked Login');
        const ic = headerIcon();
        if (!ic) return done(false, 'Waiting for the login icon...');
        if (iconKind(ic) === 'logout') return done(true, 'Already signed in', { skip: true });
        if (state.iconClicks >= 2)
          return done(false, 'Tap the login icon (top right) yourself. Icon: ' + (ic.outerHTML || '').slice(0, 90));
        state.iconClicks++;
        fireClick(ic);
        await sleep(1200);
        if (inputs(PHONE).length) return done(true, 'Opened login');
        done(false, 'Clicked the icon, waiting for the login box...');
      });
    },

    fillPhone(p) {
      return run(async () => {
        const el = inputs(PHONE)[0];
        if (!el) return done(false, 'Waiting for the phone box...');
        setVal(el, p);
        await sleep(500);
        const c =
          clickText(['get otp', 'send otp', 'generate otp', 'request otp'], true) ||
          clickText(['submit', 'continue', 'proceed'], true);
        done(true, c ? 'Phone filled, OTP requested' : 'Phone filled, tap Get OTP');
      });
    },

    loggedIn() {
      return run(async () => {
        const dlg = inputs(['otp', 'enter otp', 'registered mobile number', 'mobile number', 'mobile']);
        if (dlg.length || otpVisible()) {
          state.sawDialog = true;
          state.gone = 0;
          return done(false, '');
        }
        const ic = headerIcon();
        if (ic && iconKind(ic) === 'logout') return done(true, 'Signed in');
        if (state.sawDialog) {
          state.gone++;
          if (state.gone >= 2) return done(true, 'Signed in');
        }
        done(false, '');
      });
    },

    click(texts, exact) {
      return run(async () => {
        if (clickText(texts, !!exact)) {
          await sleep(900);
          done(true, 'Opened ' + texts[0]);
        } else {
          done(false, 'Waiting for "' + texts[0] + '"...');
        }
      });
    },

    pickDate(a) {
      return run(async () => {
        const ok = await gotoMonth(a.year, a.month - 1);
        if (!ok) return done(false, 'Could not reach that month on the calendar');
        const hdr = calHeader();
        const top = hdr ? hdr.getBoundingClientRect().bottom : 0;
        const day = String(a.day);
        let c = [
          ...document.querySelectorAll('td,button,a,div,span,li,[role=gridcell]'),
        ].filter((e) => {
          if (!vis(e)) return false;
          const r = e.getBoundingClientRect();
          return norm(e.innerText) === day && r.width <= 150 && r.height <= 150 && r.top >= top - 5 && r.top < top + 800;
        });
        c = c.filter((e) => !c.some((o) => o !== e && e.contains(o)));
        if (!c.length) return done(false, 'Waiting for day ' + day + ' on the calendar...');
        const cell = c[0];
        const st = dateState(bgOf(cell));
        if (st === 'full') return done(false, 'Quota is full on this date. Pick another date.');
        if (st === 'na') return done(false, 'Slots are not available on this date.');
        if (st === 'notreleased') return done(false, 'Quota is not released for this date yet.');
        fireClick(cell);
        await sleep(900);
        done(true, 'Date ' + day + ' selected');
      });
    },

    tickets(n) {
      return run(async () => {
        const want = String(n);
        const keys = ['number of tickets', 'no of tickets', 'tickets'];
        const s = selects(keys)[0];
        if (s && (await pickFrom(s, want))) return done(true, 'Tickets set to ' + want);
        const labs = labelEls(keys);
        if (!labs[0]) return done(false, 'Waiting for the tickets box...');
        const ctl = controlFor(labs[0]);
        const words = norm(ctl.innerText).split(' ');
        if (words[words.length - 1] === want) return done(true, 'Tickets already ' + want);
        const r = await openAndPick(ctl, want, true);
        done(r.ok, r.ok ? 'Tickets set to ' + want : 'Tickets: ' + r.why);
      });
    },

    slot(a) {
      return run(async () => {
        const all = [...document.querySelectorAll('div,span,p,label,li,mat-radio-button')].filter(
          (e) => vis(e) && (e.innerText || '').length < 90
        );
        let el = null;
        let used = '';
        for (const v of a.slots) {
          const w = ' ' + norm(v) + ' ';
          const c = all.filter((e) => (' ' + norm(e.innerText) + ' ').includes(w));
          const pref = c.filter((e) => norm(e.innerText).includes('slot time'));
          const pool = pref.length ? pref : c;
          if (pool.length) {
            el = pool.sort((x, y) => x.innerText.length - y.innerText.length)[0];
            used = v;
            break;
          }
        }
        if (!el) {
          const seen = all
            .map((e) => (e.innerText || '').trim())
            .filter((s) => /^slot time/i.test(s) && s.length < 30)
            .slice(0, 6)
            .join(' | ');
          return done(false, 'Slot ' + (a.slots[0] || '') + ' not found' + (seen ? ' (page shows: ' + seen + ')' : ''));
        }
        let card = el;
        let radio = null;
        for (let i = 0; i < 7 && card; i++) {
          radio = card.querySelector(
            'input[type=radio],mat-radio-button,[role=radio],.mat-radio-outer-circle,.mat-mdc-radio-button'
          );
          if (radio) break;
          card = card.parentElement;
        }
        if (!card) card = el;
        if (/\b(sold out|full|not available)\b/.test(norm(card.innerText)))
          return done(false, 'That slot is full. Pick another slot.');
        if (radio) {
          if (radio.tagName === 'INPUT') radio.click();
          else fireClick(radio);
        } else {
          fireClick(card);
        }
        await sleep(500);
        const inp = card.querySelector('input[type=radio]');
        if (inp && !inp.checked) {
          fireClick(card);
          await sleep(500);
          if (!inp.checked) return done(false, 'Could not tick the slot, tap it yourself');
        }
        done(true, 'Slot ' + used + ' selected');
      });
    },

    next() {
      return run(async () => {
        const onForm = () =>
          present(['pilgrim details']) || (inputs(['name']).length > 0 && inputs(['age']).length > 0);
        if (onForm()) return done(true, 'Pilgrim form is open');
        const btns = [...document.querySelectorAll('button,[role=button],a')].filter(
          (e) =>
            vis(e) &&
            !e.disabled &&
            e.getAttribute('aria-disabled') !== 'true' &&
            ['continue', 'proceed', 'next'].includes(norm(e.innerText))
        );
        if (!btns.length) return done(false, 'Waiting for the Continue button...');
        const b = btns[btns.length - 1];
        b.scrollIntoView({ block: 'center' });
        b.click();
        await sleep(1500);
        done(onForm(), 'Clicked Continue');
      });
    },

    devotees(a) {
      return run(async () => {
        const r = await fillDevotees(a.list);
        if (r.n < 0) return done(false, 'Waiting for the devotee form...');
        done(
          r.n > 0 && r.fails.length === 0,
          r.fails.length
            ? 'Not filled: ' + r.fails.join(', ') + '. Fill these yourself.'
            : 'Filled ' + r.n + ' of ' + a.list.length + ' devotees'
        );
      });
    },

    general(a) {
      return run(async () => {
        const r = await fillGeneral(a);
        done(
          r.n >= 3 && r.fails.length <= 1,
          r.fails.length ? 'Not filled: ' + r.fails.join(', ') : 'General details filled'
        );
      });
    },

    fillAll(a) {
      return run(async () => {
        const d = await fillDevotees(a.list);
        const g = await fillGeneral(a.general);
        const fails = d.fails.concat(g.fails);
        done(
          d.n > 0 || g.n > 0,
          fails.length
            ? 'Filled what I could. Not filled: ' + fails.join(', ')
            : 'Filled devotees and general details'
        );
      });
    },
  };
})();
