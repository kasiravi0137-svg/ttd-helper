(function () {
  if (window.__ttd && window.__ttd.v === 3) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) =>
    (s || '')
      .toString()
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  const vis = (e) => {
    if (!e || !e.getBoundingClientRect) return false;
    const r = e.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const s = getComputedStyle(e);
    return s.visibility !== 'hidden' && s.display !== 'none';
  };
  const has = (text, keys) => {
    const x = ' ' + norm(text) + ' ';
    return keys.some((k) => x.includes(' ' + norm(k) + ' '));
  };
  const post = (o) => {
    try {
      TTD.postMessage(JSON.stringify(o));
    } catch (e) {}
  };
  const done = (ok, msg) => post({ type: 'result', ok: !!ok, msg: msg || '' });
  const run = async (fn) => {
    try {
      await fn();
    } catch (e) {
      done(false, String(e));
    }
  };

  const PHONE = ['mobile', 'mobile number', 'mobile no', 'phone', 'phone number'];

  function labelOf(el) {
    let t = [
      el.placeholder,
      el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname'),
      el.getAttribute('name'),
    ]
      .filter(Boolean)
      .join(' ');
    let lab = null;
    if (el.id) {
      try {
        lab = document.querySelector('label[for="' + el.id + '"]');
      } catch (e) {}
    }
    if (!lab) {
      const ff = el.closest('mat-form-field,.mat-form-field,.mat-mdc-form-field');
      if (ff) lab = ff.querySelector('label,mat-label');
    }
    if (!lab && el.parentElement) lab = el.parentElement.querySelector('label');
    if (lab) t += ' ' + lab.innerText;
    return t;
  }

  function setVal(el, v) {
    const proto =
      el.tagName === 'TEXTAREA'
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    const d = Object.getOwnPropertyDescriptor(proto, 'value');
    el.scrollIntoView({ block: 'center' });
    el.focus();
    d.set.call(el, v);
    ['input', 'change', 'blur'].forEach((n) =>
      el.dispatchEvent(new Event(n, { bubbles: true }))
    );
  }

  const SKIP = ['hidden', 'checkbox', 'radio', 'button', 'submit', 'file'];
  const inputs = (keys) =>
    [...document.querySelectorAll('input,textarea')].filter(
      (e) => vis(e) && !SKIP.includes(e.type) && has(labelOf(e), keys)
    );
  const selects = (keys) =>
    [...document.querySelectorAll('select,mat-select,[role=combobox]')].filter(
      (e) => e.tagName !== 'INPUT' && vis(e) && has(labelOf(e), keys)
    );

  function clickText(texts, exact) {
    const want = texts.map(norm);
    let best = null;
    let bl = 1e9;
    document
      .querySelectorAll(
        'button,a,li,span,div,label,mat-option,[role=button],[role=option],[role=menuitem],[role=tab]'
      )
      .forEach((e) => {
        if (!vis(e)) return;
        const t = norm(e.innerText);
        if (!t || t.length > 60) return;
        const ok = want.some((w) =>
          exact ? t === w : t === w || (' ' + t + ' ').includes(' ' + w + ' ')
        );
        if (ok && t.length <= bl) {
          best = e;
          bl = t.length;
        }
      });
    if (best) {
      best.scrollIntoView({ block: 'center' });
      best.click();
      return true;
    }
    return false;
  }

  function present(texts) {
    const want = texts.map(norm);
    return [
      ...document.querySelectorAll('a,button,span,li,div,[role=button],[role=menuitem]'),
    ].some((e) => {
      if (!vis(e)) return false;
      const t = norm(e.innerText);
      return t && t.length < 40 && want.some((w) => t === w);
    });
  }

  async function clickOption(value) {
    const w = norm(value);
    const opts = [
      ...document.querySelectorAll(
        'mat-option,[role=option],.mat-option,.mat-mdc-option'
      ),
    ].filter(vis);
    const o =
      opts.find((e) => norm(e.innerText) === w) ||
      opts.find((e) => norm(e.innerText).includes(w)) ||
      opts.find((e) => norm(e.innerText).startsWith(w.slice(0, 4)));
    if (o) {
      o.click();
      await sleep(300);
      return true;
    }
    return false;
  }

  async function pickFrom(el, value) {
    const w = norm(value);
    if (el.tagName === 'SELECT') {
      const o =
        [...el.options].find((x) => norm(x.text) === w) ||
        [...el.options].find((x) => norm(x.text).includes(w));
      if (!o) return false;
      el.value = o.value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    el.scrollIntoView({ block: 'center' });
    el.click();
    await sleep(500);
    return await clickOption(value);
  }

  async function fillAny(keys, value, idx) {
    if (!value) return false;
    const s = selects(keys)[idx];
    if (s && (await pickFrom(s, value))) return true;
    const i = inputs(keys)[idx];
    if (i) {
      setVal(i, value);
      await sleep(450);
      await clickOption(value);
      return true;
    }
    return false;
  }

  async function fillDevotees(list) {
    let n = 0;
    for (let i = 0; i < list.length; i++) {
      const x = list[i];
      let names = inputs(['name']);
      if (!names[i] && i > 0) {
        clickText(['add devotee', 'add pilgrim', 'add member', 'add more devotee'], false);
        await sleep(900);
        names = inputs(['name']);
      }
      if (!names[i]) {
        if (i === 0) return -1;
        continue;
      }
      if (await fillAny(['name'], x.name, i)) n++;
      await fillAny(['age'], x.age, i);
      await fillAny(['gender', 'sex'], x.gender, i);
      await fillAny(['photo id proof', 'id proof', 'id type'], x.idType, i);
      await sleep(350);
      await fillAny(['photo id number', 'id number', 'id no'], x.idNumber, i);
    }
    return n;
  }

  async function fillGeneral(g) {
    let n = 0;
    const items = [
      [['email', 'email id', 'mail id'], g.email],
      [['city'], g.city],
      [['state'], g.state],
      [['country'], g.country],
      [['pincode', 'pin code', 'zip', 'postal code'], g.pincode],
    ];
    for (const it of items) {
      if (await fillAny(it[0], it[1], 0)) n++;
      await sleep(250);
    }
    return n;
  }

  window.__ttd = {
    v: 3,

    openLogin() {
      return run(async () => {
        if (inputs(PHONE).length) return done(true, 'Login box already open');
        if (clickText(['login', 'log in', 'sign in', 'login register', 'register login'], false))
          return done(true, 'Clicked Login');
        done(false, 'Waiting for the Login button...');
      });
    },

    fillPhone(p) {
      return run(async () => {
        const el = inputs(PHONE)[0];
        if (!el) return done(false, 'Waiting for the phone box...');
        setVal(el, p);
        await sleep(500);
        const c = clickText(
          ['get otp', 'send otp', 'generate otp', 'request otp', 'submit', 'continue', 'proceed'],
          false
        );
        done(true, c ? 'Phone filled, OTP requested' : 'Phone filled');
      });
    },

    seen(texts) {
      return run(async () => done(present(texts), ''));
    },

    click(texts) {
      return run(async () => {
        if (clickText(texts, false)) {
          await sleep(700);
          done(true, 'Clicked ' + texts[0]);
        } else {
          done(false, 'Waiting for "' + texts[0] + '"...');
        }
      });
    },

    dateSlot(a) {
      return run(async () => {
        let d = false;
        let s = false;
        const di = inputs(['date', 'darshan date', 'date of darshan'])[0];
        if (di && a.dates.length) {
          setVal(di, di.type === 'date' ? a.dates[2] : a.dates[0]);
          d = true;
        }
        if (!d) {
          const day = String(a.day);
          const cells = [
            ...document.querySelectorAll(
              'td,button,[role=gridcell],.mat-calendar-body-cell,.mat-calendar-body-cell-content,.day,.date'
            ),
          ].filter(
            (e) => vis(e) && norm(e.innerText) === day && !e.disabled && !/disabled/i.test(e.className)
          );
          if (cells[0]) {
            cells[0].click();
            d = true;
          }
        }
        await sleep(700);
        if (a.slots.length && clickText(a.slots, true)) s = true;
        done(d && s, 'Date ' + (d ? 'ok' : 'not found') + ', slot ' + (s ? 'ok' : 'not found'));
      });
    },

    devotees(a) {
      return run(async () => {
        const n = await fillDevotees(a.list);
        if (n < 0) return done(false, 'Waiting for the devotee form...');
        done(n > 0, 'Filled ' + n + ' of ' + a.list.length + ' devotees');
      });
    },

    general(a) {
      return run(async () => {
        const n = await fillGeneral(a);
        done(n >= 3, 'Filled ' + n + ' of 5 general fields');
      });
    },

    fillAll(a) {
      return run(async () => {
        const n = await fillDevotees(a.list);
        const g = await fillGeneral(a.general);
        done(n > 0 || g > 0, 'Filled ' + Math.max(n, 0) + ' devotees and ' + g + ' general fields');
      });
    },
  };
})();
